<?php

function SetUpUserAuthorization()
{
}
